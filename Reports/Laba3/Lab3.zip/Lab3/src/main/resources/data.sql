CREATE TABLE `Coefficients` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`CoefficientsX` VARCHAR(255) DEFAULT '',
	`CoefficientsY` VARCHAR(255) DEFAULT '',
	PRIMARY KEY (`id`)
);