package com.example.example.demo.book.repository;

import com.example.example.demo.book.entity.Koefs;
import org.springframework.data.repository.CrudRepository;

public interface KoefsRepository extends CrudRepository<Koefs, Long> {
}
