package com.example.example.demo.coefficients.repository;

import com.example.example.demo.coefficients.entity.Coefficients;
import org.springframework.data.repository.CrudRepository;

public interface CoefficientsRepository extends CrudRepository<Coefficients, Long> {
}
