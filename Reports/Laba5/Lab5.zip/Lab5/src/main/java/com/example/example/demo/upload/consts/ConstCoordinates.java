package com.example.example.demo.upload.consts;

public class ConstCoordinates {
    public static final int MIN_LON = 0;
    public static final int MAX_LON = 360;
    public static final int MIN_LAT = 0;
    public static final int MAX_LAT = 180;
    public static final int ZOOM = 20;
}
